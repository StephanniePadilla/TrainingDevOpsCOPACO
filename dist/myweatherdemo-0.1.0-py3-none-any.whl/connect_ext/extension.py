# -*- coding: utf-8 -*-
#
# Copyright (c) 2022, Education
# All rights reserved.
#
from connect.eaas.extension import (
    Extension,
    ProcessingResponse,
    ProductActionResponse,
    ValidationResponse,
)


class MyweatherdemoExtension(Extension):

    def process_asset_purchase_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ProcessingResponse.done()

    def process_asset_change_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ProcessingResponse.done()

    def process_asset_cancel_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ProcessingResponse.done()

    def process_asset_adjustment_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ProcessingResponse.done()

    def validate_asset_purchase_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ValidationResponse.done(request)

    def validate_asset_change_request(self, request):
        self.logger.info(f"Obtained request with id {request['id']}")
        return ValidationResponse.done(request)

    def execute_product_action(self, request):
        self.logger.info(f"Obtained product custom action with following data: {request}")
        return ProductActionResponse.done()

    def process_new_listing_request(self, request):  # pragma: no cover
        self.logger.info(
            f"Received event for listing request  {request['id']}, type {request['type']} "
            f"in status {request['state']}",
        )
        return ProcessingResponse.done()
